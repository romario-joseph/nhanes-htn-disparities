# Data Access

All data used in this analysis are publicly available from the CDC National Center for Health Statistics NHANES repository.

**Source:** https://www.cdc.gov/nchs/nhanes/index.htm  
**Cycle used:** 2017–2018  
**Access:** Free, no registration required

## How to access

The analysis script (`analysis/nhanes_analysis.py`) loads data automatically via the `nhanes` Python package. No manual download is required.

```bash
pip install nhanes
python analysis/nhanes_analysis.py
```

## Manual download (optional)

If you prefer to download the raw XPT files directly from CDC:

| File | URL |
|---|---|
| DEMO_J (Demographics) | https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.XPT |
| BPX_J (Blood Pressure) | https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/BPX_J.XPT |
| HIQ_J (Health Insurance) | https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/HIQ_J.XPT |
| BMX_J (Body Measures) | https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/BMX_J.XPT |
| DIQ_J (Diabetes) | https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DIQ_J.XPT |
| TCHOL_J (Cholesterol) | https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/TCHOL_J.XPT |
| HDL_J (HDL Cholesterol) | https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/HDL_J.XPT |

## Citation

Centers for Disease Control and Prevention, National Center for Health Statistics. National Health and Nutrition Examination Survey Data, 2017–2018. Hyattsville, MD: U.S. Department of Health and Human Services; 2020. Available at: cdc.gov/nchs/nhanes.
