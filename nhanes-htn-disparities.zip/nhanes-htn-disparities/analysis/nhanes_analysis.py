"""
Racial Disparities in Hypertension Among U.S. Adults: NHANES 2017-2018
=======================================================================
Author:      Romario Joseph, BA, MPH Candidate
Affiliation: Department of Epidemiology & Biostatistics,
             Boston University School of Public Health;
             Research Associate (2020-2025), Broad Institute of MIT and Harvard
Email:       rjoseph3@bu.edu
GitHub:      github.com/romariojoseph/nhanes-htn-disparities
Date:        March 2026

Description:
    Cross-sectional analysis of racial disparities in hypertension prevalence
    and blood pressure levels among Non-Hispanic Black vs. Non-Hispanic White
    adults using NHANES 2017-2018. Four sequential logistic regression models
    estimate unadjusted and progressively adjusted odds ratios.

Reported in accordance with STROBE guidelines for cross-sectional studies.

Dependencies:
    pip install nhanes pandas numpy scipy statsmodels matplotlib seaborn

Data:
    All data are publicly available from CDC NCHS at cdc.gov/nchs/nhanes.
    This script loads data via the nhanes Python package (no download required).

Usage:
    python nhanes_analysis.py

Outputs (saved to ./output/ and ./figures/):
    - table1.csv              Descriptive statistics by race/ethnicity
    - regression_results.csv  Logistic regression ORs across 4 models
    - htn_by_age_race.csv     HTN prevalence by age group and race
    - Figure1_HTN_Prevalence.png
    - Figure2_Forest_Plot.png
    - Figure3_SBP_Age.png
"""

import warnings
warnings.filterwarnings('ignore')

import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy import stats
from scipy.stats import chi2_contingency

# ── SETUP ─────────────────────────────────────────────────────────────────────
os.makedirs('output', exist_ok=True)
os.makedirs('figures', exist_ok=True)

# ── LOAD DATA ─────────────────────────────────────────────────────────────────
print("Loading NHANES 2017-2018 data...")
from nhanes.load import load_NHANES_data
raw = load_NHANES_data(year='2017-2018')
print(f"  Raw dataset: {len(raw)} participants, {len(raw.columns)} variables")

# ── BUILD ANALYSIS VARIABLES ──────────────────────────────────────────────────
print("Building analytic variables...")
cols = {}

# Demographics
cols['age']  = raw['AgeInYearsAtScreening']
cols['male'] = (raw['Gender'] == 'Male').astype(float)
cols['race'] = raw['RacehispanicOriginWNhAsian'].map({
    'Non-Hispanic Black':                'NHB',
    'Non-Hispanic White':                'NHW',
    'Mexican American':                  'Mexican American',
    'Non-Hispanic Asian':                'Asian',
    'Other Hispanic':                    'Other Hispanic',
    'Other Race - Including Multi-Racial': 'Other'
})

# Blood pressure — average across up to 3 readings
sbp_cols = ['SystolicBloodPres1StRdgMmHg',
            'SystolicBloodPres2NdRdgMmHg',
            'SystolicBloodPres3RdRdgMmHg']
dbp_cols = ['DiastolicBloodPres1StRdgMmHg',
            'DiastolicBloodPres2NdRdgMmHg',
            'DiastolicBloodPres3RdRdgMmHg']
cols['sbp'] = raw[sbp_cols].mean(axis=1)
cols['dbp'] = raw[dbp_cols].mean(axis=1)

# Hypertension definitions (2017 AHA/ACC)
cols['htn']  = ((cols['sbp'] >= 130) | (cols['dbp'] >= 80)).astype(float)
cols['htn2'] = ((cols['sbp'] >= 140) | (cols['dbp'] >= 90)).astype(float)

# Socioeconomic covariates
edu_map = {
    'Less than 9th grade':                                         0,
    '9-11th grade (Includes 12th grade with no diploma)':          1,
    'High school graduate/GED or equivalent':                      2,
    'Some college or AA degree':                                   3,
    'College graduate or above':                                   4,
    "Don't Know":                                                  np.nan
}
cols['education'] = raw['EducationLevelAdults20'].map(edu_map)
cols['pir']       = raw['RatioOfFamilyIncomeToPoverty'].clip(upper=5)
cols['insured']   = raw['CoveredByHealthInsurance'].apply(
    lambda x: 1.0 if x == 1.0 else (0.0 if x == 0.0 else np.nan))

# Clinical covariates
cols['bmi']       = raw['BodyMassIndexKgm2']
cols['obese']     = (raw['BodyMassIndexKgm2'] >= 30).astype(float)
cols['diabetes']  = raw['DoctorToldYouHaveDiabetes'].apply(
    lambda x: 1.0 if str(x) == '1' else (0.0 if str(x) == '0' else np.nan))
cols['total_chol']= raw['TotalCholesterolMgdl']
cols['hdl']       = raw['DirectHdlcholesterolMgdl']

df = pd.DataFrame(cols)
df['nhb']     = (df['race'] == 'NHB').astype(float)
df['age_grp'] = pd.cut(df['age'], bins=[17, 39, 59, 79, 120],
                        labels=['18-39', '40-59', '60-79', '80+'])

# ── ANALYTIC SAMPLE ───────────────────────────────────────────────────────────
# Inclusion: adults 18+, measured BP, Non-Hispanic Black or Non-Hispanic White
analytic = df[
    (df['age'] >= 18) &
    df['sbp'].notna() &
    df['race'].isin(['NHB', 'NHW'])
].copy().reset_index(drop=True)

nhb = analytic[analytic['race'] == 'NHB']
nhw = analytic[analytic['race'] == 'NHW']

print(f"  Analytic sample: N = {len(analytic)} "
      f"(NHB = {len(nhb)}, NHW = {len(nhw)})")

# ── TABLE 1: DESCRIPTIVE STATISTICS ───────────────────────────────────────────
print("\nGenerating Table 1...")

def mean_sd(s):
    return f"{s.mean():.1f} ({s.std():.1f})"

def pct_n(s):
    n = s.notna().sum()
    return f"{s.mean()*100:.1f}% [n={int(s.sum())}]"

def pval_t(a, b):
    _, p = stats.ttest_ind(a.dropna(), b.dropna())
    return f"{p:.3f}" if p >= 0.001 else "<0.001"

def pval_x(col, data):
    ct = pd.crosstab(data['race'], data[col].dropna())
    if ct.shape == (2, 2):
        _, p, _, _ = chi2_contingency(ct)
        return f"{p:.3f}" if p >= 0.001 else "<0.001"
    return "—"

rows = []
def R(label, fv, nb, nw, p="—"):
    rows.append({'Characteristic': label, 'Full Sample': fv,
                 'Non-Hispanic Black': nb, 'Non-Hispanic White': nw, 'P-value': p})

R("N", len(analytic), len(nhb), len(nhw))
R("Age, mean (SD)", mean_sd(analytic['age']), mean_sd(nhb['age']),
  mean_sd(nhw['age']), pval_t(nhb['age'], nhw['age']))
R("Male sex, n (%)", pct_n(analytic['male']), pct_n(nhb['male']),
  pct_n(nhw['male']), pval_x('male', analytic))
R("Mean SBP, mmHg (SD)", mean_sd(analytic['sbp']), mean_sd(nhb['sbp']),
  mean_sd(nhw['sbp']), pval_t(nhb['sbp'], nhw['sbp']))
R("Mean DBP, mmHg (SD)", mean_sd(analytic['dbp']), mean_sd(nhb['dbp']),
  mean_sd(nhw['dbp']), pval_t(nhb['dbp'], nhw['dbp']))
R("Hypertension (SBP>=130 or DBP>=80), n (%)",
  pct_n(analytic['htn']), pct_n(nhb['htn']),
  pct_n(nhw['htn']), pval_x('htn', analytic))
R("Stage 2 HTN (SBP>=140 or DBP>=90), n (%)",
  pct_n(analytic['htn2']), pct_n(nhb['htn2']),
  pct_n(nhw['htn2']), pval_x('htn2', analytic))
R("BMI, mean (SD)", mean_sd(analytic['bmi'].dropna()),
  mean_sd(nhb['bmi'].dropna()), mean_sd(nhw['bmi'].dropna()),
  pval_t(nhb['bmi'], nhw['bmi']))
R("Obesity (BMI>=30), n (%)",
  pct_n(analytic['obese'].dropna()),
  pct_n(nhb['obese'].dropna()),
  pct_n(nhw['obese'].dropna()),
  pval_x('obese', analytic.dropna(subset=['obese'])))
R("Diabetes (physician-diagnosed), n (%)",
  pct_n(analytic['diabetes'].dropna()),
  pct_n(nhb['diabetes'].dropna()),
  pct_n(nhw['diabetes'].dropna()),
  pval_x('diabetes', analytic.dropna(subset=['diabetes'])))
R("Income-to-poverty ratio, mean (SD)",
  mean_sd(analytic['pir'].dropna()),
  mean_sd(nhb['pir'].dropna()),
  mean_sd(nhw['pir'].dropna()),
  pval_t(nhb['pir'], nhw['pir']))
R("Health insurance coverage, n (%)",
  pct_n(analytic['insured'].dropna()),
  pct_n(nhb['insured'].dropna()),
  pct_n(nhw['insured'].dropna()),
  pval_x('insured', analytic.dropna(subset=['insured'])))
R("HDL cholesterol, mg/dL (SD)",
  mean_sd(analytic['hdl'].dropna()),
  mean_sd(nhb['hdl'].dropna()),
  mean_sd(nhw['hdl'].dropna()),
  pval_t(nhb['hdl'], nhw['hdl']))
R("Total cholesterol, mg/dL (SD)",
  mean_sd(analytic['total_chol'].dropna()),
  mean_sd(nhb['total_chol'].dropna()),
  mean_sd(nhw['total_chol'].dropna()),
  pval_t(nhb['total_chol'], nhw['total_chol']))

t1 = pd.DataFrame(rows)
t1.to_csv('output/table1.csv', index=False)
print("  Table 1 saved to output/table1.csv")

# ── LOGISTIC REGRESSION ───────────────────────────────────────────────────────
print("\nRunning logistic regression models...")

def logit(outcome, predictors, data):
    sub = data[[outcome] + predictors].dropna()
    X   = sm.add_constant(sub[predictors])
    mod = sm.Logit(sub[outcome], X).fit(disp=0, method='bfgs', maxiter=200)
    OR  = np.exp(mod.params['nhb'])
    lo, hi = np.exp(mod.conf_int().loc['nhb'])
    p   = mod.pvalues['nhb']
    n   = len(sub)
    return OR, lo, hi, p, n

results = []
for label, preds in [
    ('Model 1: Unadjusted',              ['nhb']),
    ('Model 2: + Age, Sex',              ['nhb', 'age', 'male']),
    ('Model 3: + Education, PIR, Insurance',
                                          ['nhb', 'age', 'male',
                                           'education', 'pir', 'insured']),
    ('Model 4: + BMI, Diabetes, Cholesterol',
                                          ['nhb', 'age', 'male',
                                           'education', 'pir', 'insured',
                                           'bmi', 'diabetes',
                                           'total_chol', 'hdl']),
]:
    OR, lo, hi, p, n = logit('htn', preds, analytic)
    pfmt = "<0.001" if p < 0.001 else f"{p:.3f}"
    results.append({'Model': label, 'OR': OR, 'CI_low': lo,
                    'CI_high': hi, 'p': p, 'p_fmt': pfmt, 'n': n})
    print(f"  {label}: OR={OR:.2f} (95% CI {lo:.2f}-{hi:.2f}) p={pfmt} n={n}")

rdf = pd.DataFrame(results)
rdf['OR_fmt'] = rdf.apply(lambda r: f"{r.OR:.2f} ({r.CI_low:.2f}-{r.CI_high:.2f})", axis=1)
rdf.to_csv('output/regression_results.csv', index=False)
print("  Regression results saved to output/regression_results.csv")

# ── BY-AGE SUMMARIES ──────────────────────────────────────────────────────────
age_groups = ['18-39', '40-59', '60-79', '80+']
age_race = analytic.groupby(['age_grp', 'race'], observed=True)['htn'].mean().reset_index()
age_race.to_csv('output/htn_by_age_race.csv', index=False)

sbp_age = analytic.groupby(['age_grp', 'race'], observed=True)['sbp'].mean().reset_index()

# ── FIGURE 1: PREVALENCE ──────────────────────────────────────────────────────
print("\nGenerating Figure 1...")
fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))
fig.patch.set_facecolor('white')

# Panel A
ax = axes[0]
vals  = [nhb['htn'].mean()*100, nhw['htn'].mean()*100]
clrs  = ['#1B3A6B', '#C0392B']
xlbls = [f'Non-Hispanic\nBlack (n={len(nhb):,})',
         f'Non-Hispanic\nWhite (n={len(nhw):,})']
ax.bar(xlbls, vals, color=clrs, width=0.5, edgecolor='white')

for i, (race, col) in enumerate([('NHB', '#1B3A6B'), ('NHW', '#C0392B')]):
    sub = analytic[analytic['race'] == race]['htn'].dropna()
    se  = np.sqrt(sub.mean() * (1 - sub.mean()) / len(sub)) * 1.96 * 100
    ax.errorbar(i, sub.mean()*100, yerr=se, fmt='none', color='#333333',
                capsize=5, linewidth=1.8, capthick=1.8)
    ax.text(i, sub.mean()*100 + se + 2.5,
            f"{sub.mean()*100:.1f}%", ha='center', fontsize=12,
            fontweight='bold', color=col)

ax.set_ylim(0, 78)
ax.set_ylabel('Hypertension Prevalence (%)', fontsize=11)
ax.set_title('A. Overall Hypertension Prevalence\nby Race/Ethnicity',
             fontsize=11, fontweight='bold')
ax.spines[['top', 'right']].set_visible(False)
ax.set_yticks([0, 20, 40, 60])

ym = max(vals) + 12
ax.plot([0, 0, 1, 1], [ym, ym+1, ym+1, ym], 'k-', linewidth=1.2)
ax.text(0.5, ym+2, '***  p<0.001', ha='center', fontsize=10)
diff = nhb['htn'].mean()*100 - nhw['htn'].mean()*100
ax.text(0.5, ym+6, f'Delta = {diff:.1f} percentage points',
        ha='center', fontsize=9, color='#555555')

# Panel B
ax2 = axes[1]
x = np.arange(len(age_groups))
w = 0.35

def age_val(race, grp):
    row = age_race[(age_race['age_grp'] == grp) & (age_race['race'] == race)]
    return row['htn'].values[0]*100 if len(row) > 0 else 0

nhb_v = [age_val('NHB', g) for g in age_groups]
nhw_v = [age_val('NHW', g) for g in age_groups]

b1 = ax2.bar(x - w/2, nhb_v, w, label='Non-Hispanic Black',
             color='#1B3A6B', edgecolor='white')
b2 = ax2.bar(x + w/2, nhw_v, w, label='Non-Hispanic White',
             color='#C0392B', edgecolor='white')

for b in b1:
    ax2.text(b.get_x() + b.get_width()/2, b.get_height() + 1,
             f'{b.get_height():.0f}%', ha='center', fontsize=8,
             color='#1B3A6B', fontweight='bold')
for b in b2:
    ax2.text(b.get_x() + b.get_width()/2, b.get_height() + 1,
             f'{b.get_height():.0f}%', ha='center', fontsize=8,
             color='#C0392B', fontweight='bold')

ax2.set_xticks(x)
ax2.set_xticklabels(age_groups, fontsize=10)
ax2.set_ylim(0, 100)
ax2.set_ylabel('Hypertension Prevalence (%)', fontsize=11)
ax2.set_title('B. Prevalence by Age Group', fontsize=11, fontweight='bold')
ax2.legend(fontsize=9, frameon=False)
ax2.spines[['top', 'right']].set_visible(False)

plt.suptitle(
    'Figure 1. Hypertension Prevalence Among U.S. Adults by Race/Ethnicity, NHANES 2017-2018\n'
    'Hypertension defined as SBP >= 130 mmHg or DBP >= 80 mmHg (2017 AHA/ACC criteria)',
    fontsize=9, y=1.01, color='#444444')
plt.tight_layout()
plt.savefig('figures/Figure1_HTN_Prevalence.png', dpi=150,
            bbox_inches='tight', facecolor='white')
plt.close()
print("  Figure 1 saved")

# ── FIGURE 2: FOREST PLOT ─────────────────────────────────────────────────────
print("Generating Figure 2...")
fig, ax = plt.subplots(figsize=(10, 5))
fig.patch.set_facecolor('white')

model_labels = ['Model 1\nUnadjusted', 'Model 2\n+ Age, Sex',
                'Model 3\n+ SES Factors', 'Model 4\n+ Clinical Factors']
y = np.arange(len(rdf))[::-1]
clrs2 = ['#888888', '#4A90D9', '#2166AC', '#1B3A6B']

for i, (yi, row) in enumerate(zip(y, rdf.itertuples())):
    ax.plot([row.CI_low, row.CI_high], [yi, yi],
            color=clrs2[i], linewidth=2.5, solid_capstyle='round')
    ax.plot(row.OR, yi, 'o', color=clrs2[i], markersize=10)
    ax.plot([row.CI_low], [yi], '|', color=clrs2[i],
            markersize=10, markeredgewidth=2)
    ax.plot([row.CI_high], [yi], '|', color=clrs2[i],
            markersize=10, markeredgewidth=2)
    ax.text(row.CI_high + 0.03, yi,
            f"  OR {row.OR:.2f} (95% CI {row.CI_low:.2f}-{row.CI_high:.2f})"
            f"   p {row.p_fmt}   n={row.n:,}",
            va='center', fontsize=9.5, color='#222222')

ax.axvline(x=1.0, color='#AAAAAA', linestyle='--', linewidth=1.2)
ax.set_yticks(y)
ax.set_yticklabels(model_labels, fontsize=10.5)
ax.set_xlabel('Odds Ratio (95% CI)\nNon-Hispanic Black vs. Non-Hispanic White',
              fontsize=10)
ax.set_title('Figure 2. Adjusted Odds Ratios for Hypertension\n'
             'Non-Hispanic Black vs. Non-Hispanic White Adults, NHANES 2017-2018',
             fontsize=11, pad=12)
ax.set_xlim(0.65, 2.6)
ax.spines[['top', 'right']].set_visible(False)
ax.text(1.02, -0.55, 'Reference (OR=1.0)',
        fontsize=8, color='#888888', style='italic')

plt.tight_layout()
plt.savefig('figures/Figure2_Forest_Plot.png', dpi=150,
            bbox_inches='tight', facecolor='white')
plt.close()
print("  Figure 2 saved")

# ── FIGURE 3: MEAN SBP BY AGE AND RACE ───────────────────────────────────────
print("Generating Figure 3...")

def sbp_val(race, grp):
    row = sbp_age[(sbp_age['age_grp'] == grp) & (sbp_age['race'] == race)]
    return row['sbp'].values[0] if len(row) > 0 else np.nan

sbp_nhb = [sbp_val('NHB', g) for g in age_groups]
sbp_nhw = [sbp_val('NHW', g) for g in age_groups]

fig, ax = plt.subplots(figsize=(8, 5))
fig.patch.set_facecolor('white')

ax.plot(age_groups, sbp_nhb, 'o-', color='#1B3A6B', linewidth=2.5,
        markersize=9, label='Non-Hispanic Black')
ax.plot(age_groups, sbp_nhw, 's--', color='#C0392B', linewidth=2.5,
        markersize=9, label='Non-Hispanic White')
ax.axhline(y=130, color='#E67E22', linestyle=':', linewidth=1.8,
           alpha=0.85, label='HTN threshold (130 mmHg)')
ax.fill_between(age_groups, sbp_nhb, sbp_nhw, alpha=0.07, color='#1B3A6B')

for i, (vn, vw) in enumerate(zip(sbp_nhb, sbp_nhw)):
    ax.text(i, vn + 1.8, f"{vn:.1f}", ha='center', fontsize=9,
            color='#1B3A6B', fontweight='bold')
    ax.text(i, vw - 3.5, f"{vw:.1f}", ha='center', fontsize=9,
            color='#C0392B', fontweight='bold')
    d = vn - vw
    if d > 0:
        ax.annotate(f'D{d:.1f}', xy=(i, (vn+vw)/2),
                    fontsize=7.5, color='#555555', ha='center')

ax.set_ylabel('Mean Systolic Blood Pressure (mmHg)', fontsize=11)
ax.set_xlabel('Age Group', fontsize=11)
ax.set_title('Figure 3. Mean Systolic Blood Pressure by Age Group and Race/Ethnicity\n'
             'NHANES 2017-2018', fontsize=11, pad=10)
ax.legend(fontsize=9, frameon=False, loc='upper left')
ax.set_ylim(100, 155)
ax.spines[['top', 'right']].set_visible(False)
ax.grid(axis='y', alpha=0.25, linewidth=0.5)

plt.tight_layout()
plt.savefig('figures/Figure3_SBP_Age.png', dpi=150,
            bbox_inches='tight', facecolor='white')
plt.close()
print("  Figure 3 saved")

# ── SUMMARY ───────────────────────────────────────────────────────────────────
print("\n" + "="*60)
print("ANALYSIS COMPLETE")
print("="*60)
print(f"  Analytic sample:  N = {len(analytic):,} ({len(nhb):,} NHB, {len(nhw):,} NHW)")
print(f"  HTN prevalence:   NHB {nhb['htn'].mean()*100:.1f}%  vs  NHW {nhw['htn'].mean()*100:.1f}%")
print(f"  Absolute gap:     {(nhb['htn'].mean()-nhw['htn'].mean())*100:.1f} percentage points")
print(f"  Mean SBP:         NHB {nhb['sbp'].mean():.1f}  vs  NHW {nhw['sbp'].mean():.1f} mmHg")
print()
for _, r in rdf.iterrows():
    print(f"  {r.Model}: OR {r.OR:.2f} "
          f"(95% CI {r.CI_low:.2f}-{r.CI_high:.2f})  "
          f"p={r.p_fmt}  n={int(r.n):,}")
print()
print("Outputs:")
print("  output/table1.csv")
print("  output/regression_results.csv")
print("  output/htn_by_age_race.csv")
print("  figures/Figure1_HTN_Prevalence.png")
print("  figures/Figure2_Forest_Plot.png")
print("  figures/Figure3_SBP_Age.png")
